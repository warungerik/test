<!DOCTYPE html>
<html lang="id"
    <?php if(Request::is('auth/*')): ?> class="dark-style customizer-hide" data-theme="theme-default"
   <?php else: ?>   data-theme="dark" <?php endif; ?>>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?php echo e(asset($website->header->favicon)); ?>">

    <meta name="description" content="<?php echo $website->header->description; ?>">
    <meta name="keyword" content="<?php echo e($website->header->keywords); ?>">
    <meta name="author" content="@akiracode">
    <meta name="theme-color" content="<?php echo e($website->header->theme_color); ?>" />
    <meta name="robots" content="index, follow">
    <meta content="desktop" name="device">
    <meta name="coverage" content="Worldwide">
    <meta name="apple-mobile-web-app-title" content="<?php echo e($website->header->apple_mobile_web_app_title); ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="mobile-web-app-capable" content="yes">

    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e(url('/')); ?>">
    <meta property="og:title" content="<?php echo e($website->header->og->title); ?>">
    <meta property="og:site_name" content="<?php echo e($website->header->og->site_name); ?>">
    <meta property="og:description" content="<?php echo $website->header->og->description; ?>">
    <meta property="og:image" content="<?php echo e($website->header->og->image->url); ?>">
    <meta property="og:image:alt" content="<?php echo e($website->header->og->image->alt); ?>">

    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"rel="stylesheet"
        type="text/css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
</head>

<body class="antialiased">
    <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    <div id="StoreContainer"></div>
    <a id="backToTopBtn" onclick="scrollToTop()"
        class="floating-btu d-flex justify-content-center gap-1 flex-column contact d-none" tabindex="0">
        <i class="bi bi-arrow-up"></i>
    </a>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/js/all.min.js"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\laravel\store\resources\views/app.blade.php ENDPATH**/ ?>