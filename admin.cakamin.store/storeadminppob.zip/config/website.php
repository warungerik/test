<?php

return [
    'config' => null,
    'all' => null
];
